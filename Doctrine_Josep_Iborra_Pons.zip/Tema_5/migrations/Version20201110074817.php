<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20201110074817 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE producto ADD id INT AUTO_INCREMENT NOT NULL, ADD compania VARCHAR(255) DEFAULT NULL, ADD descripcion LONGTEXT DEFAULT NULL, DROP compañia, DROP descripción, CHANGE img img VARCHAR(50) NOT NULL, CHANGE titulo titulo VARCHAR(255) DEFAULT NULL, CHANGE autor autor VARCHAR(100) DEFAULT NULL, CHANGE precio precio DOUBLE PRECISION NOT NULL, ADD PRIMARY KEY (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE producto MODIFY id INT NOT NULL');
        $this->addSql('ALTER TABLE producto DROP PRIMARY KEY');
        $this->addSql('ALTER TABLE producto ADD compañia TEXT NOT NULL COLLATE utf8mb4_general_ci, ADD descripción TEXT NOT NULL COLLATE utf8mb4_general_ci, DROP id, DROP compania, DROP descripcion, CHANGE img img TEXT NOT NULL COLLATE utf8mb4_general_ci, CHANGE titulo titulo TEXT NOT NULL COLLATE utf8mb4_general_ci, CHANGE autor autor TEXT NOT NULL COLLATE utf8mb4_general_ci, CHANGE precio precio INT NOT NULL');
    }
}
