<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;


class RecibeController extends AbstractController
{
    /**
     * @Route("/recibe", name="recibe")
     */
    public function recibe(Request $request,SessionInterface $session)
    {
        $nombre=$request->request->get('name');
        $email=$request->request->get('email');
        $subject=$request->request->get('subject');
        $message=$request->request->get("message");
        $usuname = $session->get('usuario');
        $usulog = strlen($usuname)>0?"Buenas ".$usuname:"";

        return $this->render('recibe.html.twig', [
            'name' => $nombre,
            'email'=> $email,
            'subject'=> $subject,
            'message'=> $message,
            'usuario'=>$usulog
        ]);
        
    }
}
