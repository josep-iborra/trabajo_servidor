<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Session\SessionInterface;


class IndexController extends AbstractController
{
    /**
     * @Route("/", name="index")
     */
    public function index(SessionInterface $session)
    {
        $usuname = $session->get('usuario');
        $usulog = strlen($usuname)>0?"Buenas ".$usuname:"";
        return $this->render('index.html.twig', [
            'usuario' => $usulog
        ]);
    }
}
