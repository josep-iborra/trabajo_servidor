<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Session\SessionInterface;


class LoginController extends AbstractController
{
    /**
     * @Route("/login", name="login")
     */
    public function login(SessionInterface $session)
    {
        $usuname = $session->get('usuario');
        $usulog = strlen($usuname)>0?"Buenas ".$usuname:"";
        return $this->render('login.html.twig', [
            'usuario' => $usulog
        ]);
    }
}
