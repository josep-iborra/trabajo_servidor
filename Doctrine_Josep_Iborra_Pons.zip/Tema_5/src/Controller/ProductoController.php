<?php

namespace App\Controller;
use App\Entity\Producto;
use App\Entity\Categoria;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class ProductoController extends AbstractController
{
    /**
     * @Route("/producto/{producto<Todos|Nature Lifestyle|Awesome Layouts|Creative Ideas|Responsive Templates|HTML5 / CSS3 Templates|Creative & Unique>?Todos}{currentPage?1}", name="producto")
     */
    public function producto(SessionInterface $session,$currentPage,Request $request,$producto)
    {
        $Result =$this->getDoctrine()
                      ->getRepository(Producto::Class)
                      ->findAll();

        $usuname = $session->get('usuario');
        $usulog = strlen($usuname)>0?"Buenas ".$usuname:"";
        
        if($producto == 'Todos'){
            $Result=$this->getDoctrine()
                    ->getRepository(Producto::class)
                    ->findAll();
        }else{
            $categoria=$this->getDoctrine()
                    ->getRepository(Categoria::class)
                    ->findOneBy(['categoria'=>$producto]); 

            $Result=$categoria->getProductos();
        }

        return $this->render('producto.html.twig', [
            'usuario' => $usulog,
            'data' => $Result,
            'currentPage' => $currentPage,
            'itemsPerPage' => 2
        ]);
        
        
    }

    /* private $servicios = [
        "Allservicios" =>[
            [
                "img" => "blog-thumb-01.jpg",
                "titulo" =>"Lifestyle",
                "autor" =>"Donec tincidunt leo",
                "compañia" =>"Admin",
                "fecha" =>"May 31, 2020",
                "precio" =>"45",
                "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
                
            ],
            [
                "img" => "blog-thumb-02.jpg",
                "titulo" =>"Lifestyle",
                "autor" =>"Donec tincidunt leo",
                "compañia" =>"Admin",
                "fecha" =>"May 22, 2020",
                "precio" =>"45",
                "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
            ],
            [
                "img" => "blog-thumb-03.jpg",
                "titulo" =>"Lifestyle",
                "autor" =>"Donec tincidunt leo",
                "compañia" =>"Admin",
                "fecha" =>"May 14, 2020",
                "precio" =>"45",
                "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
            ],
            [
                "img" => "blog-thumb-04.jpg",
                "titulo" =>"Lifestyle",
                "autor" =>"Donec tincidunt leo",
                "compañia" =>"Admin",
                "fecha" =>"May 28, 2020",
                "precio" =>"45",
                "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
            ],
            [
                "img" => "blog-thumb-05.jpg",
                "titulo" =>"Lifestyle",
                "autor" =>"Donec tincidunt leo",
                "compañia" =>"Admin",
                "fecha" =>"May 29, 2020",
                "precio" =>"45",
                "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
            ],
            [
                "img" => "blog-thumb-06.jpg",
                "titulo" =>"Lifestyle",
                "autor" =>"Donec tincidunt leo",
                "compañia" =>"Admin",
                "fecha" =>"May 8, 2020",
                "precio" =>"45",
                "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
            ]
        ]
    ]; */
}
