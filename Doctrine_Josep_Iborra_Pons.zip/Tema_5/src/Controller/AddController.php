<?php

namespace App\Controller;

use App\Entity\Producto;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class AddController extends AbstractController
{
    /**
     * @Route("/add", name="add")
     */
    public function index(EntityManagerInterface $entityManager)
    {
        foreach($this->servicios as $key => $value){
            foreach($value as $product){
                $servicios=new Producto();
                $servicios->setImg($product["img"]);
                $servicios->setTitulo($product["titulo"]);
                $servicios->setAutor($product["autor"]);
                $servicios->setCompania($product["compania"]);
                $servicios->setFecha(new\Datetime($this->cambiarFormato($product['fecha'])));
                $servicios->setPrecio($product["precio"]);
                $servicios->setDescripcion($product["descripcion"]);
                
                $entityManager->persist($servicios);
            }
            $entityManager->flush();
        }
        return $this->render('add.html.twig', [
            'controller_name' => 'AddController',
        ]);
    }

 private function cambiarFormato($fecha){
    $fecha = str_replace("," , "" ,$fecha);
    $fecha_array = explode(" ", $fecha);

    $mes = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    return $fecha_array[2] . "-" . (array_search($fecha_array[0], $mes) + 1) . "-" . $fecha_array[1];

}
    private $servicios = [
    "Allservicios" =>[
        [
            "img" => "blog-thumb-01.jpg",
            "titulo" =>"Lifestyle",
            "autor" =>"Donec tincidunt leo",
            "compania" =>"Admin",
            "fecha" =>"May 31, 2020",
            "precio" =>"45",
            "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
            
        ],
        [
            "img" => "blog-thumb-02.jpg",
            "titulo" =>"Lifestyle",
            "autor" =>"Donec tincidunt leo",
            "compania" =>"Admin",
            "fecha" =>"May 22, 2020",
            "precio" =>"45",
            "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
        ],
        [
            "img" => "blog-thumb-03.jpg",
            "titulo" =>"Lifestyle",
            "autor" =>"Donec tincidunt leo",
            "compania" =>"Admin",
            "fecha" =>"May 14, 2020",
            "precio" =>"45",
            "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
        ],
        [
            "img" => "blog-thumb-04.jpg",
            "titulo" =>"Lifestyle",
            "autor" =>"Donec tincidunt leo",
            "compania" =>"Admin",
            "fecha" =>"May 28, 2020",
            "precio" =>"45",
            "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
        ],
        [
            "img" => "blog-thumb-05.jpg",
            "titulo" =>"Lifestyle",
            "autor" =>"Donec tincidunt leo",
            "compania" =>"Admin",
            "fecha" =>"May 29, 2020",
            "precio" =>"45",
            "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
        ],
        [
            "img" => "blog-thumb-06.jpg",
            "titulo" =>"Lifestyle",
            "autor" =>"Donec tincidunt leo",
            "compania" =>"Admin",
            "fecha" =>"May 8, 2020",
            "precio" =>"45",
            "descripcion" =>"Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend."
        ]
    ]
];
}

